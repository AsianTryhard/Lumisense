<?
$conn = new mysqli("localhost", "root", "root", "angelhack");

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$img = imagecreatefromjpeg($_FILES['file']['tmp_name']);

/*$x1 = floor($_POST['x1'] * imagesx($img) / 295);
$y1 = floor($_POST['y1'] * imagesx($img) / 295);
$w1 = floor($_POST['w1'] * imagesx($img) / 295);
$h1 = floor($_POST['h1'] * imagesx($img) / 295);
$x2 = floor($_POST['x2'] * imagesx($img) / 295);
$y2 = floor($_POST['y2'] * imagesx($img) / 295);
$w2 = floor($_POST['w2'] * imagesx($img) / 295);
$h2 = floor($_POST['h2'] * imagesx($img) / 295);*/

$x1 = $_POST['x1'];
$y1 = $_POST['y1'];
$w1 = $_POST['w1'];
$h1 = $_POST['h1'];
$x2 = floor($_POST['x2'] * imagesx($img) / 295);
$y2 = floor($_POST['y2'] * imagesx($img) / 295);
$w2 = floor($_POST['w2'] * imagesx($img) / 295);
$h2 = floor($_POST['h2'] * imagesx($img) / 295);

$tmp_img = ImageCreateTrueColor(1, 1);
ImageCopyResampled($tmp_img, $img, 0, 0, $x1, $y1, 1, 1, $w1, $h1);
$rgb = ImageColorAt($tmp_img,0,0);

$r = ($rgb >> 16) & 0xFF;
$g = ($rgb >> 8) & 0xFF;
$b = $rgb & 0xFF;

imagefilter($img, IMG_FILTER_COLORIZE, 255 - $r, 255 - $g, 255 - $b);
$arr = array("x" => $x2, "y" => $y2, "width" => $w2, "height" => $h2);
$img2 = imagecrop($img, $arr);

$targetPath = "uploadimages/" . generateRandomString(20) . "." . end((explode(".", $_FILES['file']['name'])));
imagejpeg($img2, $targetPath);

$uniqueid = rand(100000, 999999);

$conn->query("INSERT INTO images (uniqueid, data, date) VALUES (" . $uniqueid . ", '" . $targetPath . "', " . time() . ")");
echo $uniqueid;
?>