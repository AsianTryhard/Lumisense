<!DOCTYPE html>
	<html>
	<head>
		<title>Kek</title>
		<meta name="viewport" content = "width = device-width, initial-scale = 1.0, minimum-scale = 1, maximum-scale = 1, user-scalable = no" />
		<meta name="apple-mobile-web-app-title" content="O'Brien" />
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="default" />
		<link rel="apple-touch-icon" href="Logo.jpeg">
		<link rel="apple-touch-icon" sizes="76x76" href="Logo.jpeg">
		<link rel="apple-touch-icon" sizes="120x120" href="Logo.jpeg">
		<link rel="apple-touch-icon" sizes="152x152" href="Logo.jpeg">
		<link rel="apple-touch-startup-image" href="iPhoneStartup.png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script type="text/javascript">
		$(document).ready(function(){
		        // iOS web app full screen hacks.
		        if(window.navigator.standalone == true) {
		                // make all link remain in web app mode.
		                $('a').click(function() {
		                        window.location = $(this).attr('href');
		            return false;
		                });
		        }
		});
		</script>
		<script src="jquery.Jcrop.min.js"></script>
		<link href="style.css" rel="stylesheet" />
		<link href="jquery.Jcrop.min.css" rel="stylesheet" />
	</head>
	<body>
		<iframe id="frame" name="frame"></iframe>
		<form action="uploadimage.php" method="post" target="frame" id="form">
			<input type="file" id="file" name="file" onchange="previewimage(this)" />
			<input type="hidden" id="uniqueid" name="uniqueid" value="" />
			<input type="hidden" id="x1" name="x1" />
			<input type="hidden" id="y1" name="y1" />
			<input type="hidden" id="w1" name="w1" />
			<input type="hidden" id="h1" name="h1" />
			<input type="hidden" id="x2" name="x2" />
			<input type="hidden" id="y2" name="y2" />
			<input type="hidden" id="w2" name="w2" />
			<input type="hidden" id="h2" name="h2" />
		</form>
		<div class="header">Product Title</div>
		<div class="select" ontouchend="$('#file').trigger('click');type = 'calibration';$(this).removeClass('touched');" ontouchstart="$(this).addClass('touched');"><span>Take Photo for</span> Calibration</div>
		<div class="select" ontouchend="$('#file').trigger('click');cat = 'product';$(this).removeClass('touched');" ontouchstart="$(this).addClass('touched');"><span>Take Photo of</span> Product</div>
		<div class="overlay" ontouchend="closeoverlay()">
			<img src="loading.gif" class="loading" />
		</div>
		<script>
		var cat;
		var step = 1;

		function previewimage(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e) {
					$(".overlay").show();
					$(".overlay").html("<p style='margin-top: 60px;'>Select a region with only the white paper</p><img src='" + e.target.result + "' class='previewimage' />");
					$(".overlay").attr("ontouchend", "");
					$('.previewimage').Jcrop({
					    onSelect: showNext,
					    onRelease: hideNext
					}, function() {
						jcrop_api = this;
					});
				};
				reader.readAsDataURL(input.files[0]);
			}
		}

		function showNext(c) {
			$("#x" + step).val(c.x);
			$("#y" + step).val(c.y);
			$("#w" + step).val(c.w);
			$("#h" + step).val(c.h);
			$(".overlay").append("<div class='button' ontouchstart='$(this).addClass(\"active\");' ontouchend='$(this).removeClass(\"active\");next" + step + "();'>Next Step</div>");
		}

		function hideNext() {
			$(".button").remove();
		}

		function next1() {
			$(".overlay p").html("Select the region containing the desired color");
			step = 2;
			jcrop_api.destroy();
			$('.previewimage').Jcrop({
			    onSelect: showNext,
			    onRelease: hideNext
			}, function() {
				jcrop_api = this;
			});
			$(".button").remove();
		}

		function next2() {
			var formData = new FormData($('#form')[0]);
			var imgurl = "";

			$('.overlay').html('<img src=\'loading.gif\' class=\'loading\' />');

            $.ajax({
                url: 'uploadimage.php',
                type: 'POST',
                data: formData,
                success: function (data) {
					$(".overlay").html('<h4>The photo ID is:</h4><div class="id">' + data + '</div><p>Tap to exit. This code may only be used once.</p>');
					$("#form").reset();
					$(".overlay").on("touchend", function() {
						closeoverlay();
					})
                },
                cache: false,
                contentType: false,
                processData: false
            });

            return false;
		}

		function upload(input) {
			var formData = new FormData($('#form')[0]);
			var imgurl = "";
			$(".overlay").show();

            $.ajax({
                url: 'uploadimage.php',
                type: 'POST',
                data: formData,
                success: function (data) {
					$(".overlay").html('<h4>The photo ID is:</h4><div class="id">' + data + '</div><p>Tap to exit. This code may only be used once.</p>');
					$("#form").reset();
                },
                cache: false,
                contentType: false,
                processData: false
            });

            return false;
		}

		function closeoverlay() {
			$('.overlay').hide();
			$('.overlay').html('<img src=\'loading.gif\' class=\'loading\' />');
		}
		</script>
	</body>
</html>