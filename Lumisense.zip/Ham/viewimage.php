<?
$conn = new mysqli("localhost", "root", "root", "angelhack");
$result = $conn->query("SELECT * FROM images WHERE uniqueid = " . $_GET['id'] . " LIMIT 1");
while($row = $result->fetch_assoc()) {
	if($row['active'] == 0) {
		echo "<img src='" . $row['data'] . "' />";
	} else {
		echo "false";
	}
}
$conn->query("UPDATE images SET active = 1 WHERE uniqueid = " . $_GET['id']);